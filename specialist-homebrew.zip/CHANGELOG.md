
---
# Version 1.0

Initial release of module. Migrated content from (specialist-homebrew-tool-kits)[https://github.com/NickTheRipperEX/specialist-homebrew-tool-kits/] to this module instead.


## TO-DO

* Add everything else in the main document. See the details of all the homebrew to be included as [single comprehrensive document on homebrewery](https://homebrewery.naturalcrit.com/share/A4VYfH4m84o8)

---